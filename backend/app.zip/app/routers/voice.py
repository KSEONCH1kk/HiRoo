import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.deps import get_db, get_current_active_user
from app.models.user import User
from app.models.server import ServerMember
from app.models.channel import Channel
from app.models.voice import VoiceState
from app.schemas.notification import VoiceJoin, VoiceStateUpdate, VoiceStateResponse
from app.services.websocket_service import manager

router = APIRouter(prefix="/api/voice", tags=["voice"])


@router.post("/join", response_model=VoiceStateResponse)
async def join_voice(
    body: VoiceJoin,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(select(Channel).where(Channel.id == body.channel_id, Channel.type == "voice"))
    channel = result.scalar_one_or_none()
    if not channel:
        raise HTTPException(status_code=404, detail="Voice channel not found")

    member_result = await db.execute(
        select(ServerMember).where(
            ServerMember.server_id == channel.server_id,
            ServerMember.user_id == current_user.id,
        )
    )
    if not member_result.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="Not a member of this server")

    vs_result = await db.execute(select(VoiceState).where(VoiceState.user_id == current_user.id))
    vs = vs_result.scalar_one_or_none()
    if vs:
        vs.channel_id = body.channel_id
        vs.server_id = channel.server_id
    else:
        vs = VoiceState(user_id=current_user.id, channel_id=body.channel_id, server_id=channel.server_id)
        db.add(vs)
    await db.flush()

    await manager.broadcast_to_server(str(channel.server_id), {
        "event": "voice_state_update",
        "data": VoiceStateResponse.model_validate(vs).model_dump(mode="json"),
    })
    return vs


@router.post("/leave", status_code=204)
async def leave_voice(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(select(VoiceState).where(VoiceState.user_id == current_user.id))
    vs = result.scalar_one_or_none()
    if not vs:
        return

    server_id = vs.server_id
    vs.channel_id = None
    vs.server_id = None
    await db.flush()

    if server_id:
        await manager.broadcast_to_server(str(server_id), {
            "event": "voice_state_update",
            "data": {"user_id": str(current_user.id), "channel_id": None, "server_id": None},
        })


@router.patch("/state", response_model=VoiceStateResponse)
async def update_voice_state(
    body: VoiceStateUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(select(VoiceState).where(VoiceState.user_id == current_user.id))
    vs = result.scalar_one_or_none()
    if not vs or not vs.channel_id:
        raise HTTPException(status_code=400, detail="Not in a voice channel")

    if body.is_muted is not None:
        vs.is_muted = body.is_muted
    if body.is_deafened is not None:
        vs.is_deafened = body.is_deafened
    if body.is_sharing_screen is not None:
        vs.is_sharing_screen = body.is_sharing_screen
    if body.is_video is not None:
        vs.is_video = body.is_video
    await db.flush()

    if vs.server_id:
        await manager.broadcast_to_server(str(vs.server_id), {
            "event": "voice_state_update",
            "data": VoiceStateResponse.model_validate(vs).model_dump(mode="json"),
        })
    return vs
