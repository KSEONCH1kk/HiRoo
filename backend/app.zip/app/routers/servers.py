import uuid
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.core.deps import get_db, get_current_active_user, require_server_member, require_server_admin
from app.core.security import generate_invite_code
from app.core.rate_limit import limiter, LIMIT_API
from app.models.user import User
from app.models.server import Server, ServerMember
from app.schemas.server import (
    ServerCreate, ServerUpdate, ServerResponse,
    ServerMemberResponse, ServerMemberUpdate, InviteResponse,
)
from app.services.websocket_service import manager

router = APIRouter(prefix="/api/servers", tags=["servers"])


@router.post("/", response_model=ServerResponse, status_code=201)
async def create_server(
    body: ServerCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    server = Server(
        name=body.name,
        description=body.description,
        owner_id=current_user.id,
        invite_code=generate_invite_code(),
    )
    db.add(server)
    await db.flush()

    # Add owner as member
    member = ServerMember(server_id=server.id, user_id=current_user.id, role="owner")
    db.add(member)

    # Create default channels
    from app.models.channel import Channel
    for i, (name, ctype) in enumerate([("общий-чат", "text"), ("Главная комната", "voice")]):
        db.add(Channel(server_id=server.id, name=name, type=ctype, position=i))

    await db.flush()
    await db.refresh(server)
    return _server_response(server, 1)


@router.get("/join/{invite_code}", response_model=ServerResponse)
async def join_server(
    invite_code: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(select(Server).where(Server.invite_code == invite_code))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Invalid invite code")

    if server.invite_expires_at and server.invite_expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=410, detail="Invite link has expired")

    existing = await db.execute(
        select(ServerMember).where(
            ServerMember.server_id == server.id, ServerMember.user_id == current_user.id
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Already a member")

    member = ServerMember(server_id=server.id, user_id=current_user.id, role="member")
    db.add(member)
    await db.flush()

    count = await _member_count(db, server.id)
    await manager.broadcast_to_server(str(server.id), {
        "event": "member_join",
        "data": {"server_id": str(server.id), "user_id": str(current_user.id)},
    })
    manager.join_server(str(server.id), str(current_user.id))
    return _server_response(server, count)


@router.get("/{server_id}", response_model=ServerResponse)
async def get_server(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    member: ServerMember = Depends(require_server_member),
):
    result = await db.execute(select(Server).where(Server.id == server_id))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    count = await _member_count(db, server.id)
    return _server_response(server, count)


@router.patch("/{server_id}", response_model=ServerResponse)
async def update_server(
    server_id: uuid.UUID,
    body: ServerUpdate,
    db: AsyncSession = Depends(get_db),
    admin: ServerMember = Depends(require_server_admin),
):
    result = await db.execute(select(Server).where(Server.id == server_id))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if body.name is not None:
        server.name = body.name
    if body.description is not None:
        server.description = body.description
    await db.flush()
    count = await _member_count(db, server.id)
    return _server_response(server, count)


@router.delete("/{server_id}", status_code=204)
async def delete_server(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(select(Server).where(Server.id == server_id))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != current_user.id:
        raise HTTPException(status_code=403, detail="Only the owner can delete this server")
    await db.delete(server)


@router.post("/{server_id}/leave", status_code=204)
async def leave_server(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    member: ServerMember = Depends(require_server_member),
):
    if member.role == "owner":
        raise HTTPException(status_code=400, detail="Owner must transfer ownership before leaving")
    await db.delete(member)
    await manager.broadcast_to_server(str(server_id), {
        "event": "member_leave",
        "data": {"server_id": str(server_id), "user_id": str(current_user.id)},
    })


@router.get("/{server_id}/members", response_model=list[ServerMemberResponse])
async def list_members(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: ServerMember = Depends(require_server_member),
):
    result = await db.execute(
        select(ServerMember).where(ServerMember.server_id == server_id)
    )
    return result.scalars().all()


@router.patch("/{server_id}/members/{user_id}", response_model=ServerMemberResponse)
async def update_member(
    server_id: uuid.UUID,
    user_id: uuid.UUID,
    body: ServerMemberUpdate,
    db: AsyncSession = Depends(get_db),
    _: ServerMember = Depends(require_server_admin),
):
    result = await db.execute(
        select(ServerMember).where(ServerMember.server_id == server_id, ServerMember.user_id == user_id)
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    if body.role is not None:
        member.role = body.role
    if body.nickname is not None:
        member.nickname = body.nickname
    await db.flush()
    return member


@router.delete("/{server_id}/members/{user_id}", status_code=204)
async def kick_member(
    server_id: uuid.UUID,
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    admin: ServerMember = Depends(require_server_admin),
):
    result = await db.execute(
        select(ServerMember).where(ServerMember.server_id == server_id, ServerMember.user_id == user_id)
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    if member.role == "owner":
        raise HTTPException(status_code=403, detail="Cannot kick the server owner")
    await db.delete(member)


@router.post("/{server_id}/invite", response_model=InviteResponse)
async def regenerate_invite(
    server_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: ServerMember = Depends(require_server_admin),
):
    result = await db.execute(select(Server).where(Server.id == server_id))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    server.invite_code = generate_invite_code()
    await db.flush()
    return InviteResponse(invite_code=server.invite_code, expires_at=server.invite_expires_at)


# helpers
def _server_response(server: Server, count: int) -> ServerResponse:
    r = ServerResponse.model_validate(server)
    r.member_count = count
    return r


async def _member_count(db: AsyncSession, server_id: uuid.UUID) -> int:
    result = await db.execute(
        select(func.count()).where(ServerMember.server_id == server_id)
    )
    return result.scalar() or 0
