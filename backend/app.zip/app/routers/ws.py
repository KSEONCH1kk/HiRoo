import json
import uuid
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.security import verify_access_token
from app.core.deps import get_db, get_redis
from app.models.user import User
from app.models.server import ServerMember
from app.services.websocket_service import manager
import redis.asyncio as aioredis

router = APIRouter(tags=["websocket"])


@router.websocket("/ws")
async def websocket_endpoint(
    ws: WebSocket,
    token: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
    redis: aioredis.Redis = Depends(get_redis),
):
    await ws.accept()
    user: User | None = None

    try:
        # Auth via query param or first message
        if token:
            payload = verify_access_token(token)
            if payload and not await redis.get(f"blacklist:{token}"):
                result = await db.execute(select(User).where(User.id == uuid.UUID(payload["sub"])))
                user = result.scalar_one_or_none()

        if not user:
            # Wait for identify message
            try:
                raw = await ws.receive_text()
                data = json.loads(raw)
                if data.get("event") == "identify":
                    t = data.get("data", {}).get("token", "")
                    payload = verify_access_token(t)
                    if payload and not await redis.get(f"blacklist:{t}"):
                        result = await db.execute(select(User).where(User.id == uuid.UUID(payload["sub"])))
                        user = result.scalar_one_or_none()
            except Exception:
                pass

        if not user:
            await ws.send_text(json.dumps({"event": "error", "data": {"message": "Unauthorized"}}))
            await ws.close(code=4001)
            return

        # Register connection
        manager.connect(str(user.id), ws)

        # Join all servers user belongs to
        result = await db.execute(
            select(ServerMember.server_id).where(ServerMember.user_id == user.id)
        )
        for (sid,) in result.all():
            manager.join_server(str(sid), str(user.id))

        await ws.send_text(json.dumps({"event": "ready", "data": {"user_id": str(user.id)}}))

        # Update status to online
        user.status = "online"
        await db.flush()

        # Main receive loop
        while True:
            raw = await ws.receive_text()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            event = data.get("event")
            payload = data.get("data", {})

            if event == "typing_start":
                channel_id = payload.get("channel_id")
                dm_id = payload.get("dm_id")
                await manager.broadcast_to_server(
                    payload.get("server_id", ""),
                    {"event": "typing", "data": {"user_id": str(user.id), "channel_id": channel_id, "is_typing": True}},
                    exclude_user=str(user.id),
                )

            elif event == "typing_stop":
                channel_id = payload.get("channel_id")
                await manager.broadcast_to_server(
                    payload.get("server_id", ""),
                    {"event": "typing", "data": {"user_id": str(user.id), "channel_id": channel_id, "is_typing": False}},
                    exclude_user=str(user.id),
                )

            elif event == "voice_signal":
                target_id = payload.get("target_user_id")
                if target_id:
                    await manager.send_to_user(target_id, {
                        "event": "voice_signal",
                        "data": {
                            "from_user_id": str(user.id),
                            "signal_data": payload.get("signal_data"),
                        },
                    })

    except WebSocketDisconnect:
        pass
    finally:
        if user:
            manager.disconnect(str(user.id), ws)
            if not manager.is_online(str(user.id)):
                user.status = "offline"
                try:
                    await db.flush()
                except Exception:
                    pass
