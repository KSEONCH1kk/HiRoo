import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, and_

from app.core.deps import get_db, get_current_active_user
from app.models.user import User
from app.models.friend import FriendRequest
from app.schemas.friend import FriendRequestCreate, FriendRequestResponse, FriendResponse
from app.services.websocket_service import manager
from app.services.notification_service import create_notification

router = APIRouter(prefix="/api/friends", tags=["friends"])


@router.get("/", response_model=list[FriendResponse])
async def list_friends(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(FriendRequest).where(
            or_(
                FriendRequest.from_user_id == current_user.id,
                FriendRequest.to_user_id == current_user.id,
            ),
            FriendRequest.status == "accepted",
        )
    )
    requests = result.scalars().all()
    friends = []
    for req in requests:
        other_id = req.to_user_id if req.from_user_id == current_user.id else req.from_user_id
        user_result = await db.execute(select(User).where(User.id == other_id))
        u = user_result.scalar_one_or_none()
        if u:
            friends.append(u)
    return friends


@router.get("/pending", response_model=list[FriendRequestResponse])
async def pending_requests(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(FriendRequest).where(
            FriendRequest.to_user_id == current_user.id,
            FriendRequest.status == "pending",
        )
    )
    return result.scalars().all()


@router.post("/request", response_model=FriendRequestResponse, status_code=201)
async def send_friend_request(
    body: FriendRequestCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(select(User).where(User.username == body.username))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot send friend request to yourself")

    existing = await db.execute(
        select(FriendRequest).where(
            or_(
                and_(FriendRequest.from_user_id == current_user.id, FriendRequest.to_user_id == target.id),
                and_(FriendRequest.from_user_id == target.id, FriendRequest.to_user_id == current_user.id),
            )
        )
    )
    existing_req = existing.scalar_one_or_none()
    if existing_req:
        if existing_req.status == "accepted":
            raise HTTPException(status_code=409, detail="Already friends")
        if existing_req.status == "pending":
            raise HTTPException(status_code=409, detail="Friend request already sent")
        if existing_req.status == "blocked":
            raise HTTPException(status_code=403, detail="Cannot send request")

    req = FriendRequest(from_user_id=current_user.id, to_user_id=target.id, status="pending")
    db.add(req)
    await db.flush()
    await db.refresh(req)

    await create_notification(db, target.id, "friend_request", from_user_id=current_user.id)
    await manager.send_to_user(str(target.id), {
        "event": "friend_request",
        "data": {"from_user_id": str(current_user.id), "username": current_user.username},
    })
    return req


@router.post("/request/{request_id}/accept", response_model=FriendRequestResponse)
async def accept_request(
    request_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(FriendRequest).where(
            FriendRequest.id == request_id,
            FriendRequest.to_user_id == current_user.id,
            FriendRequest.status == "pending",
        )
    )
    req = result.scalar_one_or_none()
    if not req:
        raise HTTPException(status_code=404, detail="Friend request not found")
    req.status = "accepted"
    await db.flush()
    return req


@router.post("/request/{request_id}/reject", status_code=204)
async def reject_request(
    request_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(FriendRequest).where(
            FriendRequest.id == request_id,
            FriendRequest.to_user_id == current_user.id,
            FriendRequest.status == "pending",
        )
    )
    req = result.scalar_one_or_none()
    if not req:
        raise HTTPException(status_code=404, detail="Friend request not found")
    req.status = "rejected"


@router.delete("/{user_id}", status_code=204)
async def unfriend(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(FriendRequest).where(
            or_(
                and_(FriendRequest.from_user_id == current_user.id, FriendRequest.to_user_id == user_id),
                and_(FriendRequest.from_user_id == user_id, FriendRequest.to_user_id == current_user.id),
            ),
            FriendRequest.status == "accepted",
        )
    )
    req = result.scalar_one_or_none()
    if not req:
        raise HTTPException(status_code=404, detail="Not friends")
    await db.delete(req)


@router.post("/block/{user_id}", status_code=204)
async def block_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    existing = await db.execute(
        select(FriendRequest).where(
            or_(
                and_(FriendRequest.from_user_id == current_user.id, FriendRequest.to_user_id == user_id),
                and_(FriendRequest.from_user_id == user_id, FriendRequest.to_user_id == current_user.id),
            )
        )
    )
    req = existing.scalar_one_or_none()
    if req:
        req.status = "blocked"
        req.from_user_id = current_user.id
        req.to_user_id = user_id
    else:
        db.add(FriendRequest(from_user_id=current_user.id, to_user_id=user_id, status="blocked"))


@router.delete("/block/{user_id}", status_code=204)
async def unblock_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    result = await db.execute(
        select(FriendRequest).where(
            FriendRequest.from_user_id == current_user.id,
            FriendRequest.to_user_id == user_id,
            FriendRequest.status == "blocked",
        )
    )
    req = result.scalar_one_or_none()
    if req:
        await db.delete(req)
